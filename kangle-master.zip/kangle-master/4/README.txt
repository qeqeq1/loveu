Hello！
------
：![kangleisok][1]
此页面可替换“Kangle is ok”（域名已解析但没有绑定）
演示页面：[点我传送][3]
