Hello！
------
这是我的一些小“作品” 一般来说用于替换Kangle的丑陋的默认页面
目前有的：![kangleisok][1]
此页面可替换“Kangle is ok”（域名已解析但没有绑定）
传送门：[点我传送][2]
演示页面：[点我传送][3]
自适应 在宽屏设备上显示背景图 手机上则不显示

  [1]: https://i.loli.net/2018/10/04/5bb5ae5a81395.png
  [2]: https://github.com/qeqeq1/kangle
  [3]: https://qeqeq1.github.io/kangle/4
